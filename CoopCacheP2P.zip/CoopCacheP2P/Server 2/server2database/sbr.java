import java.awt.*;
import java.applet.*;
/*<applet code =sbr.class height=400 width=400></applet>*/ 
public class sbr extends Applet implements ActionListener
{

Label l1 =new  Label("enter no 1");
Label l2 =new  Label("enter no 2");
TextField t1=new TextField(20);
TextField t2=new TextField(20);
TextField t3=new TextField(20);
Button b1=new Button("command");
Button b2=new Button("clear");

public void init()
{
  setBackground(Color.pink);
  setLayout(null);
  l1.setForeground(Color.red);
 l1.setBounds(30,30,240,300);
 add(l1);
 
t1.setForeground(Color.blue);
t1.setBounds(290,30,240,30);
add(t1);
 
l2.setForeground(Color.red);
 l2.setBounds(30,60,240,30);
 add(l2);


t2.setForeground(Color.blue);
t2.setBounds(300,60,240,30);
add(t1);
 
b1.setBounds(40,80,240,30);
add(b1);


b2.setBounds(80,80,240,30);
add(b2);

b1.addActionListener(this);
b2.addActionListener(this);

t3.setBounds(100,130,240,30);
add(t3);
}


public void actionPerformed(ActionEvent e)
{
if(e.getSource().equals(b1))
{
  String s1=t1.getText();
  int a=Integer.parseInt(s1);
  String s2=t2.getText();
  int b=Integer.parseInt(s2);
  int sum=a+b;
 
  t3.setText(String.valueOf(sum));
 }

if(e.getSource().equals(b2))
{
t1.setText("");
t2.setText("");
t3.setText("");
t1.requestFocusInWindow();
}
}
}
 
