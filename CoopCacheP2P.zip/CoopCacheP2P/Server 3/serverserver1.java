import javax.swing.*;
import java.net.*;
import java.io.*;
import java.awt.event.*;
import java.awt.*;
	

 class x implements ActionListener
 {
//	String msg="";

	int port,oldport;

long stime,etime,delay;
	String msg="";
	String info="";
	int n2;

InetAddress add;
	String ss;

	JFrame jm=new JFrame(" SERVER SYSTEM 9000 ");

	JLabel heading=new JLabel(" SERVER SYSTEM 9000 ");

	JLabel l1=new JLabel(" File Name ");
	JLabel l2=new JLabel(" File Information ");

	JTextField t1=new JTextField(20);

//	JTextArea t1=new JTextArea(20,6);
	JTextArea t2=new JTextArea(20,6);
	JButton b1=new JButton(" Clear ");
	JButton b2=new JButton(" Exit ");
JTextArea t3=new JTextArea(20,6);

	JLabel l3=new JLabel(" File Search Details ");

	JScrollPane js,js1;

	JPanel p1=new JPanel();
	JPanel p11=new JPanel();
	ServerSocket server;
JPanel p22=new JPanel();

	Socket rec,sen,sss;	

		Socket s;
		PrintWriter p;
		BufferedReader b;

	//x()
	//{
 	//	try
	//	{
	//		server=new ServerSocket(6000);
	//	}
      	//	catch(Exception xx)
	//	{
	//		System.out.println(xx);
	//	}	
//	} 



	void display()
	{

		jm.setSize(1300,800);
		jm.setLayout(null);
		
		p1.setBounds(0,0,1300,800);
		p1.setBackground(Color.pink);
		p1.setLayout(null);
		jm.add(p1);
	
		p11.setBounds(480,70,780,540);
		p11.setBackground(Color.pink);
		p11.setLayout(null);
		p11.setBackground(new java.awt.Color(180, 120, 120));
		p1.setBackground(new java.awt.Color(10, 120, 120));
	//	p11.setBackground(new java.awt.Color(130, 150, 130));
		
		p1.add(p11);

		heading.setBounds(500,10,300,30);
		heading.setForeground(Color.yellow);
		heading.setFont(new Font("cambria",Font.BOLD,26));
		p1.add(heading);
	
	
	//	l1.setBackground(new java.awt.Color(30, 30, 30));
	
		l1.setForeground(Color.black);
		l1.setFont(new Font("times new roman",Font.BOLD,22));
		l1.setBounds(30,50,170,30);
		p11.add(l1);

		t1.setBounds(200,50,500,32);
		t1.setForeground(Color.red);
		t1.setBackground(Color.white);
		t1.setFont(new Font("times new roman",Font.BOLD,18));	
		p11.add(t1);


		l2.setForeground(Color.black);
		l2.setFont(new Font("times new roman",Font.BOLD,22));
		l2.setBounds(30,110,200,30);
		p11.add(l2);


		p22.setBounds(30,70,430,540);
		p22.setBackground(Color.pink);
		p22.setLayout(null);
//		p22.setBackground(new java.awt.Color(200, 150, 120));
		p22.setBackground(new java.awt.Color(150, 150, 150));
	//	p1.setBackground(new java.awt.Color(10, 120, 120));
	//	p22.setBackground(new java.awt.Color(130, 150, 130));
		p1.add(p22);


		js=new JScrollPane(t2,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		js.setBounds(200,110,500,400);
		t2.setForeground(Color.blue);
		t2.setBackground(Color.white);
		t2.setFont(new Font("times new roman",Font.BOLD,18));	
		p11.add(js);

		l3.setForeground(Color.yellow);
		l3.setFont(new Font("times new roman",Font.BOLD,22));
		l3.setBounds(20,40,200,30);
		p22.add(l3);


		js1=new JScrollPane(t3,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		js1.setBounds(20,80,380,420);
		t3.setForeground(Color.blue);
		t3.setBackground(Color.pink);
		t3.setFont(new Font("times new roman",Font.BOLD,18));	
		p22.add(js1);



		b1.setBounds(800,640,150,40);
		b1.setForeground(Color.red);
		b1.setBackground(Color.yellow);
		b1.setFont(new Font("times new roman",Font.BOLD,22));
		p1.add(b1);

		b2.setBounds(970,640,150,40);
		b2.setBackground(Color.pink);
		b2.setForeground(Color.red);
		b2.setFont(new Font("comic sans ms",Font.BOLD,22));
		p1.add(b2);


		b1.addActionListener(this);
		b2.addActionListener(this);


		jm.setVisible(true);
		jm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		try
		{
			while(true)
			{
				server=new ServerSocket(9000);
				s=new Socket();
				s=server.accept();

				java.util.Date today=new java.util.Date();

				 add=s.getInetAddress();
				 System.out.println(s +"\t"+ add);
				 String name=add.getHostAddress();
				 System.out.println(name);
				 int port=s.getLocalPort();
				 System.out.println(port);

				b=new BufferedReader(new InputStreamReader(s.getInputStream()));
				String n;
			
				n=b.readLine();
				port=Integer.parseInt(n);
				System.out.println(port);

			if(port==8001 || port==8002 || port==8003 )
			{		
				oldport=port;
	
				n=b.readLine();
				ss=n;
				Thread.sleep(2000);

				JOptionPane.showMessageDialog(jm," Request Arrived From "+port +" for File : "+ss);

				t3.append("\n------------------------------------------------------------------\n");
				t3.append(" Searchnig File Name :\t" +ss+" \n");

				stime=System.currentTimeMillis();

				t3.append("Start Date/ Time : "+today+" \n");
				t3.append("Start Time : "+String.valueOf(stime)+" -  ms \n");
			
				t3.append(" From Address : "+name +"\\"+String.valueOf(port));
			
				do
				{
					   n=b.readLine();
					  if(n.compareTo("EXIT")!=0)
					{		 
					  msg=msg+n;
					}
				}while(n.compareTo("EXIT")!=0); 

				System.out.println(s);		
				t1.setText(ss);
				msg="";
				t3.append("\n Searched File Name : "+ss);

				File ffound=new File("server3database\\"+ss);


				System.out.println("c:\\serverdatabase\\"+ss);

				boolean ex = ffound.exists();
				  if (!ex)
				  {
					//stime=System.currentTimeMillis();

					Thread.sleep(3000);
		Thread.sleep(2000);

					JOptionPane.showMessageDialog(jm,"File "+ ss+" Not Found Here, Sending To Server 5050 ");

					//t3.append("Start Time : "+String.valueOf(stime)+"\t ms \n");
					t3.append("\nSending to Server : LocalHost:5050 \n");
					sss=new Socket("localhost",5050);
					p=new PrintWriter(sss.getOutputStream(),true);
					p.println("9000");
					p.println("1");
					p.println(t1.getText());
					System.out.println(t1.getText());
					p.println("EXIT");
					//t1.setText("");
					t1.requestFocusInWindow();
					sss.close();
					//String s=JOptionPane.showInputDialog(jm,"Enter Value of N");
					//	t1.setText(s);
					sss.close();	
					server.close();
					s.close();
					//display();
				}
				else
				{
					  FileInputStream fin=new FileInputStream("server3database\\"+ss);
				
					Thread.sleep(3000);
					

					JOptionPane.showMessageDialog(jm,"File "+ ss+" is Found Here, Sending Result To Server " + port);

			
					t3.append("\n Result : File Found \n \t Successfull Search ");
					
					etime=System.currentTimeMillis();
				
					t3.append("Searched Time : "+String.valueOf(etime)+"\t ms \n");
				
					t3.append("\n------------------------------------------------------------------\n");
				
			
					while((n2=fin.read())!=-1)
					{	
						info=info+(char)n2;
					}					
					sen=new Socket("localhost",port);
					p=new PrintWriter(sen.getOutputStream(),true);
					p.println("9000");
					//p.println("1");
					p.println("Found");
					p.println(info);
					p.println("EXIT");
					t2.setText(info);
					t2.requestFocusInWindow();
					sen.close();
					s.close();
					server.close();
					info="";			
					//display();  
					t2.setText(info);	
					//display();
			    }
					s.close();
					server.close();
					//display();
			}
			else if(port==5050)
			{
				n=b.readLine();
				if(Integer.parseInt(n)==3)
				{

					System.out.println(" Searching");
					n=b.readLine();
				ss=n;
Thread.sleep(2000);
				JOptionPane.showMessageDialog(jm," Request Arrived From "+port +" for File : "+ss);

				t3.append("\n------------------------------------------------------------------\n");
				t3.append(" Searchnig File Name :\t" +ss+" \n");

				stime=System.currentTimeMillis();

				t3.append("Start Date/ Time : "+today+" \n");
				t3.append("Start Time : "+String.valueOf(stime)+" -  ms \n");
			
				t3.append(" From Address : "+name +"\\"+String.valueOf(port));
			
				do
				{
					   n=b.readLine();
					  if(n.compareTo("EXIT")!=0)
					{		 
					  msg=msg+n;
					}
				}while(n.compareTo("EXIT")!=0); 

				System.out.println(s);		
				t1.setText(ss);
				msg="";
				t3.append("\n Searched File Name : "+ss);

				File ffound=new File("server3database\\"+ss);


				System.out.println("c:\\serverdatabase\\"+ss);

				boolean ex = ffound.exists();
				  if (!ex)
				  {
					//stime=System.currentTimeMillis();

					Thread.sleep(3000);

					JOptionPane.showMessageDialog(jm,"File "+ ss+" Not Found Here, Sending To Server 5050 ");

					//t3.append("Start Time : "+String.valueOf(stime)+"\t ms \n");
					t3.append("\nSending to Server : LocalHost:5050 \n");
					sss=new Socket("localhost",5050);
					p=new PrintWriter(sss.getOutputStream(),true);
					p.println("9000");
					p.println("3");
					p.println("Not Found");
					System.out.println("Not Found");
					p.println("EXIT");
					//t1.setText("");
					t1.requestFocusInWindow();
					sss.close();
					//String s=JOptionPane.showInputDialog(jm,"Enter Value of N");
					//	t1.setText(s);
					sss.close();	
					server.close();
					s.close();
					//display();
				}
				else
				{
					  FileInputStream fin=new FileInputStream("server3database\\"+ss);
				
					Thread.sleep(3000);
			
					JOptionPane.showMessageDialog(jm,"File "+ ss+" is Found Here, Sending Result To Server " + port);

			
					t3.append("\n Result : File Found \n \t Successfull Search ");
					
					etime=System.currentTimeMillis();
				
					t3.append("Searched Time : "+String.valueOf(etime)+"\t ms \n");
				
					t3.append("\n------------------------------------------------------------------\n");
				
			
					while((n2=fin.read())!=-1)
					{	
						info=info+(char)n2;
					}					
					sen=new Socket("localhost",port);
					p=new PrintWriter(sen.getOutputStream(),true);
					p.println("9000");
					p.println("3");
					p.println("Found");
					p.println(info);
					p.println("EXIT");
					t2.setText(info);
					t2.requestFocusInWindow();
					sen.close();
					s.close();
					server.close();
					info="";			
					//display();  
					t2.setText(info);	
					//display();
			   		 }
					s.close();
					server.close();
					//display();
					
				}
				else if(Integer.parseInt(n)==2)
				{

				        System.out.println("Returned");	
				        System.out.println("\n\nFROM CLIENT \n\n");
				        System.out.println("Message Recived From 5050 ");
					//n=b.readLine();
					String result=b.readLine();
					System.out.println(result);
					if(result.equals("Not Found"))
					{
					//stime=System.currentTimeMillis();
			
					//t3.append("Sending to Server : LocalHost:5050 \n");
			
					Thread.sleep(3000);
					JOptionPane.showMessageDialog(jm,"Sorry , File "+ ss+" Not Found In Server 5050 , Un Successfully Search ");

					t2.setText("File Not Found At Server" + port +"\n");
					t3.append("File Not Found At Server" + port +"\n");
					etime=System.currentTimeMillis();
					t3.append("End Time : "+String.valueOf(etime)+"\t ms\n");
					delay=(etime-stime);

					 t3.append("\n Result : File Not Found : 5050 \n \t UnSuccessfull Search ");

					t3.append(" Delay  : "+String.valueOf(delay)+"\t ms\n");
					t3.append("__________________________________________\n");
			
					//t2.append(msg);
					sen=new Socket("localhost",oldport);
					p=new PrintWriter(sen.getOutputStream(),true);
					p.println(t2.getText());
					p.println("EXIT");
					sen.close();
					sss.close();
					server.close();
					s.close();
					//display();

				}
				else
				{
					Thread.sleep(3000);

					JOptionPane.showMessageDialog(jm,"Congrates, File "+ ss+" Found In Server 5050 , Successfully Search ");

					do
					{
					   n=b.readLine();
					  if(n.compareTo("EXIT")!=0)
					{		 
						Thread.sleep(100);
						  msg=msg+n+"\n";
					}
					}while(n.compareTo("EXIT")!=0); 
				t2.setText("File found \n From Server :: " + port +"\n");
				t2.append(msg);
				sen=new Socket("localhost", oldport);
				p=new PrintWriter(sen.getOutputStream(),true);
				p.println(t2.getText());
				p.println("EXIT");
				t2.setText(info);
			
				FileOutputStream fout=new FileOutputStream("D:\\IMP CLIENT SERVER PROGRAM\\Co-Op Cache 111\\Server 3\\server3database\\" +ss);
			
			int len=msg.length();
			char c;

			for(int i=0;i<len;i++)
			{
				c=msg.charAt(i);
				fout.write((char)c);
			}	

			Thread.sleep(3000);
	

			JOptionPane.showMessageDialog(jm," File Now  Stored in Cache Memory ");


			

				t2.requestFocusInWindow();
				sen.close();
				s.close();
				server.close();
				sen.close();
					sss.close();
					server.close();
					s.close();
					info="";	
				 t3.append("\n Result : File Found :\t"+port +"\n \t Successfull Search ");
				  t3.append("\n------------------------------------------------------------------\n");
			        }	
		}
		else if(Integer.parseInt(n)==1)
		{
			n=b.readLine();
			ss=n;
			
			System.out.println(ss);		
	
			t1.setText(ss);
			msg="";

			stime=System.currentTimeMillis();
			
			t3.append("\n__________________________________________\n");
			t3.append(" \nStart Time : "+String.valueOf(stime)+"\t ms \n");
				
			t3.append("\n Searched File Name : "+ss);
			File ffound=new File("server3database\\"+ss);
			
			boolean ex = ffound.exists();
			t3.append("\nSEARCHING FILE \t"+ ss);
			  if (!ex)
			  {
				
				t3.append("\nSending Reply to Server : LocalHost:5050 ");
				etime=System.currentTimeMillis();
				sss=new Socket("localhost",5050);
				p=new PrintWriter(sss.getOutputStream(),true);
				p.println("9000");
				p.println("2");
				p.println("Not Found");
				System.out.println("Not Found");
				p.println("EXIT");
				//t1.setText("");
				t1.requestFocusInWindow();
				 t3.append("\n Result : File Not Found Found :9000 \n \t UnSuccessfull Search ");
				t3.append(" \nEnd Time : "+String.valueOf(etime)+"\t ms ");
				  t3.append("\n------------------------------------------------------------------\n");
				sss.close();
				//String s=JOptionPane.showInputDialog(jm,"Enter Value of N");
				//	t1.setText(s);
				sss.close();	
				sss.close();	
				server.close();
				s.close();
			}
		         else
			{	
				  FileInputStream fin=new FileInputStream("server3database\\"+ss);
				 
				  t3.append("\n Result : File Found :9000 \n \t Successfull Search ");
				  
				 while((n2=fin.read())!=-1)
			 		{	
						info=info+(char)n2;
					}				
				sen=new Socket("localhost",port);
				p=new PrintWriter(sen.getOutputStream(),true);
				p.println("9000");
				p.println("2");
				p.println(info);
				p.println("EXIT");
				t2.setText(info);
				t2.requestFocusInWindow();
				sen.close();
				s.close();
				server.close();
				info="";			
				//display();  
				t2.setText(info);
sss.close();	
				server.close();
				s.close();
				etime=System.currentTimeMillis();
				t3.append(" \nEnd Time : "+String.valueOf(etime)+"\t ms \n");
				  t3.append("\n------------------------------------------------------------------\n");
					
				//display();
			}
				s.close();
				server.close();
				//display();	


				//sen=new Socket("localhost",port);
				//p=new PrintWriter(sen.getOutputStream(),true);
				//p.println("9000");
				//p.println("from 9000 u get result");
				//p.println("EXIT");
				
			
		}
					
			}

		
			}

		}
		catch(Exception e)
		{
			System.out.println(e);
		}		
	

	}

  public void actionPerformed(ActionEvent e)
  {
	if(e.getSource().equals(b2))
	{
		System.exit(0);
	}

	if(e.getSource().equals(b1))
	{
		t1.setText("");
		t2.setText("");
		t1.requestFocusInWindow();
		display();
	
	}
	else
	{
		System.exit(0);
	}
  }

}
	

 class serverserver1
 {
	public static  void main(String args[])
	{
		x x1=new x();
		x1.display();
	
		
	}
}