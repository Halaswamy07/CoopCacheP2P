import java.io.*;

class mjmain
{
  public static void main(String args[])
  {
	File dir=new File(args[0]);
	String filelist[]=dir.list();

	if(filelist==null)
	{
		System.out.println(" Dir Does not Exit");
	}
	else
	{
		for(int i=0;i<filelist.length;i++)
		{
			System.out.println(filelist[i]);
		}
	}
    }
 }


/*
   java mjmain c:\java

   java mjmain c:\java\jdk1.5.0

   java mjmain c:\java\jdk1.5.0\bin
