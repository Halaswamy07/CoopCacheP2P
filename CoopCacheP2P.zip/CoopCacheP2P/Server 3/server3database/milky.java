hai how are you 
nice  meet you
then what are you doing
