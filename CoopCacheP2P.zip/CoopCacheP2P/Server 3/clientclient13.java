import javax.swing.*;
import java.net.*;
import java.io.*;
import java.awt.event.*;
import java.awt.*;
	

 class x implements ActionListener
 {
	
	long stime,etime,delay;

	String msg="";

	JFrame jm=new JFrame("CLIENT SYSTEM 8003 ");

	JLabel heading=new JLabel("CLIENT SYSTEM 8003 ");

	JLabel l1=new JLabel(" File Name ");
	JLabel l2=new JLabel(" Reply Recieved");

	JLabel l3=new JLabel(" File Search Details ");

	JTextField t1=new JTextField(20);

//	JTextArea t1=new JTextArea(20,6);

	JTextArea t2=new JTextArea(20,6);

	JTextArea t3=new JTextArea(20,6);

	JButton b1=new JButton("Search");

	JButton b2=new JButton(" Clear ");

	JButton b3=new JButton(" Exit ");

	JScrollPane js,js1;

	JPanel p1=new JPanel();
	JPanel p11=new JPanel();
	JPanel p22=new JPanel();

	ServerSocket server;
	Socket rec;	

		Socket s;
		PrintWriter p;
		BufferedReader b;

	//x()
	//{
 	//	try
	//	{
	//		server=new ServerSocket(6000);
	//	}
      	//	catch(Exception xx)
	//	{
	//		System.out.println(xx);
	//	}	
//	} 



	void display()
	{

		jm.setSize(1300,900);
		jm.setLayout(null);
		
		p1.setBounds(0,0,1300,900);
		p1.setBackground(Color.pink);
		p1.setLayout(null);
		jm.add(p1);
	
		p11.setBounds(20,70,750,540);
		p11.setBackground(Color.pink);
		p11.setLayout(null);
		p11.setBackground(new java.awt.Color(180, 120, 120));
		p1.setBackground(new java.awt.Color(10, 120, 120));
	//	p11.setBackground(new java.awt.Color(130, 150, 130));
		
		p1.add(p11);


		p22.setBounds(780,70,430,540);
		p22.setBackground(Color.pink);
		p22.setLayout(null);
//		p22.setBackground(new java.awt.Color(200, 150, 120));
		p22.setBackground(new java.awt.Color(150, 150, 150));
	//	p1.setBackground(new java.awt.Color(10, 120, 120));
	//	p22.setBackground(new java.awt.Color(130, 150, 130));
		p1.add(p22);

		l3.setForeground(Color.yellow);
		l3.setFont(new Font("times new roman",Font.BOLD,22));
		l3.setBounds(20,40,200,30);
		p22.add(l3);


		js1=new JScrollPane(t3,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		js1.setBounds(20,80,380,420);
		t3.setForeground(Color.blue);
		t3.setBackground(Color.white);
		t3.setFont(new Font("times new roman",Font.BOLD,18));	
		p22.add(js1);

		heading.setBounds(350,10,300,30);
		heading.setForeground(Color.yellow);
		heading.setFont(new Font("cambria",Font.BOLD,26));
		p1.add(heading);
	
	
	//	l1.setBackground(new java.awt.Color(30, 30, 30));
	
		l1.setForeground(Color.black);
		l1.setFont(new Font("times new roman",Font.BOLD,22));
		l1.setBounds(30,50,170,30);
		p11.add(l1);

		t1.setBounds(200,50,400,32);
		t1.setForeground(Color.red);
		t1.setBackground(Color.white);
		t1.setFont(new Font("times new roman",Font.BOLD,18));	
		p11.add(t1);


		l2.setForeground(Color.black);
		l2.setFont(new Font("times new roman",Font.BOLD,22));
		l2.setBounds(30,110,200,30);
		p11.add(l2);


		js=new JScrollPane(t2,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		js.setBounds(200,110,500,400);
		t2.setForeground(Color.red);
		t2.setBackground(Color.white);
		t2.setFont(new Font("times new roman",Font.BOLD,18));	
		p11.add(js);




		b1.setBounds(605,50,100,30);
		b1.setForeground(Color.red);
		b1.setFont(new Font("times new roman",Font.BOLD,18));
		p11.add(b1);

		b2.setBounds(780,630,120,35);
		b2.setForeground(Color.red);
		b2.setFont(new Font("times new roman",Font.BOLD,18));
		p1.add(b2);


		b3.setBounds(940,630,120,35);
		b3.setForeground(Color.red);
		b3.setFont(new Font("times new roman",Font.BOLD,18));
		p1.add(b3);


		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);


		jm.setVisible(true);
		jm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		try
		{
			while(true)
			{
			server=new ServerSocket(8003);
			s=new Socket();
			s=server.accept();
			b=new BufferedReader(new InputStreamReader(s.getInputStream()));
			String n;
			//n=b.readLine();
			do
			{
			   n=b.readLine();
			  if(n.compareTo("EXIT")!=0)
			{	
				Thread.sleep(100);
			 
			  msg=msg+n+"\n";
			}
			}while(n.compareTo("EXIT")!=0); 
			
			java.util.Date today=new java.util.Date();
	
				Thread.sleep(2000);
			t2.setText(msg);
			msg="";
	
			etime=System.currentTimeMillis();
	
			t3.append("End Time : "+String.valueOf(etime)+"\t ms\n");
			
			delay=(etime-stime)/1000;

			t3.append(" Delay  : "+String.valueOf(delay)+"\t ms\n");

			t3.append("__________________________________________\n");

		
			t3.setVisible(true);
			
			server.close();
			s.close();
			//display();
			
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}		
	

	}

  public void actionPerformed(ActionEvent e)
  {
	if(e.getSource().equals(b3))
	{
		System.exit(0);
	}
	if(e.getSource().equals(b2))
	{
		t1.setText("");
		t2.setText("");
		t3.setText("");
		t1.requestFocusInWindow();
	display();
		
	
	//	String s=JOptionPane.showInputDialog(jm,"Enter Value of N");
	//	t1.setText(s);
	}

	if(e.getSource().equals(b1))
	{
		try
		{
			if(t1.getText().equals(""))
			{
				JOptionPane.showMessageDialog(jm,"Please Enter File Name TO Be Search");
				t1.requestFocusInWindow();;
			}
			else
			{
			//t3.setText("");
			stime=System.currentTimeMillis();

			java.util.Date today=new java.util.Date();
	
			JOptionPane.showMessageDialog(jm," Request To Search File : "+ t1.getText() +" is Sent To Server 9000");
			t3.append("__________________________________________\n");
			t3.append("Sending to Server : LocalHost:9000 \n");
					t3.append("File Name :\t"+t1.getText());
			
			t3.append("Start Date / Time : "+today+"\t ms \n");
			t3.append("Start Time in ms : "+String.valueOf(stime)+" - ms \n");
			
			s=new Socket("localhost",9000);
			p=new PrintWriter(s.getOutputStream(),true);
			p.println("8003");
			p.println(t1.getText());
			p.println("EXIT");
			//t1.setText("");
			t1.requestFocusInWindow();
			s.close();
		//	String s=JOptionPane.showInputDialog(jm,"Enter Value of N");
		//	t1.setText(s);

			s.close();	
			//display();
			}	

		}
		catch(Exception eee)
		{
			System.out.println(eee);
		}
		}
  }

}
	

 class clientclient13
 {
	public static  void main(String args[])
	{
		x x1=new x();
		x1.display();
	
		
	}
}